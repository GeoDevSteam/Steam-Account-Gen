Run the file 'Steam-Account-Gen-v1'

Enter the email you would like associated with the accounts,
Click ' Generate' and choose the number of accounts you would like to be created.